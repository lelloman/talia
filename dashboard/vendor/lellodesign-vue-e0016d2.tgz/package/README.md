# @lelloman/lellodesign-vue

For upgrades, start with the [shared release mapping](../../CHANGELOG.md), then
read this package's [release notes](RELEASES.md) and the
[open-workspace migration checklist](../../docs/upgrades/open-workspace.md).
The open-workspace APIs documented below are currently **unreleased**.


Initial Vue 3.5+ implementation of LelloDesign: semantic tokens, scoped native
HTML styling, 18 components, and a consumer playground. No Vuetify, PrimeVue,
router, state store, or auth SDK dependency. Vue is a peer dependency.

Version 0.1.0 is the initial Fucina release. See the repository’s
`docs/publishing.md` for registry access, credentials, and the release procedure.
Version 0.2.0 adds header controls, textarea, button-link, badge and confirmation
components, plus array-valued checkboxes. The host still owns application state.

## Build, try, and install

From this directory, using Node 22.12+ (tested with Node 24):

```sh
npm ci
npm run build
npm run dev
```

Open the URL printed by Vite. The playground imports the built package through
its public exports, not its component sources. `npm run build:demo` creates a
static playground in `demo-dist/`; `npm run dev` rebuilds the library on startup.
Restart it after library changes to rebuild those exports.

The primary distribution route is Fucina. Configure the consuming service’s `.npmrc`:

```ini
@lelloman:registry=https://fucina.homelab/api/packages/lelloman/npm/
//fucina.homelab/api/packages/lelloman/npm/:_authToken=${FUCINA_NPM_TOKEN}
```

Supply the token through the environment and trust the private HTTPS CA, then:

```sh
npm install --save-exact @lelloman/lellodesign-vue@0.2.0
```

A local archive remains useful for unpublished changes: run `npm pack` in this
source directory, then in a Vue 3.5+ service:

```sh
npm install /absolute/path/to/lelloman-lellodesign-vue-0.2.0.tgz
```

```ts
import '@lelloman/lellodesign-vue/style.css'
```

The stylesheet includes bundled color/layout tokens, base rules, and component
styles. Import it once. Vue is external to the library bundle and is not installed
as a second runtime. Typed ESM exports and declarations are included in the archive.

## Theme and ordinary HTML

```vue
<script setup lang="ts">
import { LelloTheme, LelloButton, LelloInput } from '@lelloman/lellodesign-vue'
import { ref } from 'vue'
const name = ref('Alex')
</script>

<template>
  <LelloTheme theme="blue-light">
    <h1>Settings</h1>
    <LelloInput v-model="name" label="Display name" autocomplete="name" />
    <LelloButton type="submit">Save changes</LelloButton>
    <label>Notes <textarea /></label>
  </LelloTheme>
</template>
```

`LelloTheme` defaults to `blue-light` and `base=true`. Set `theme` to an exported
`LelloThemeName`; `themes` lists all 22 bundled themes. The host owns appearance
selection and persistence. Invalid runtime theme names fall back to blue-light.
All semantic `--ld-*` roles and layout values are inherited by descendants.

Base styling covers headings, paragraphs, links, buttons, text inputs, native
selects, textareas, checkboxes/radios, fieldsets, tables, disclosures, blockquotes,
code, separators, disabled states, validation borders, and focus. It is scoped to
the wrapper and intentionally low-specificity. It does not change the host body's
margin or reset unrelated parts of the page.

For gradual migration, `:base="false"` retains tokens and explicit components but
turns off native-element rules. A `lello-unstyled` subtree opts out of base element
rules while still inheriting the theme's typography, tokens, and focus treatment.
This is not complete CSS isolation: nested themed roots inside an enabled base
root still inherit that ancestor's base rules. Use separate roots for separately
styled areas. Third-party widgets may need explicit overrides or replacement.

Custom components can consume tokens and utilities: `lv-stack`, `lv-row`,
`lv-grid`, `lv-muted`, `lv-scroll`, and `lv-sr-only`. Wrap wide native tables in
`lv-scroll`. A token-only CSS entry is also available as `tokens.css`; it does
not include component styles. Native range/date/file controls keep browser behavior;
this package does not implement custom pickers or a full widget suite.

## Component API

| Export | Main API |
| --- | --- |
| `LelloTheme` | `theme`, `base`; default content slot |
| `LelloScaffold` | `productName`, `title`, `items`, `active`, `mobileNavigation`, `showMobileAccount`, `v-model:collapsed`; `navigate(item, event)` |
| `LelloAccount` | `name`, `src`, `compact`, `label`; emits `activate` |
| `LelloAvatar` | `name`, `src`; decorative soft hexagon, initials fallback on image failure |
| `LelloButton` | `variant`: primary/secondary/neutral/danger/ghost; `type`, `disabled`, `loading` |
| `LelloField` | `label`, `id`, `hint`, `error`, `required`; scoped slot with `id`, `describedBy`, `invalid`, `required` |
| `LelloInput` | String `v-model`, field props; native attributes/events fall through to input |
| `LelloSelect` | String `v-model`, `options: {value,label,disabled?}[]`, field props; native attributes/events fall through |
| `LelloCheckbox` | Boolean or string-array `v-model`, `label`; provide `value` for array membership; native attributes/events fall through |
| `LelloTextarea` | String `v-model`, same field metadata as Input; native attributes/events fall through |
| `LelloButtonLink` | Required `href`, button `variant` (default neutral); real anchor with native link behavior |
| `LelloBadge` | `tone`: info/success/warning/error/neutral; required meaningful text in default slot |
| `LelloSignOutButton` | Neutral door/arrow action with built-in confirmation; `iconOnly` (default true), `disabled`, `loading`, `label`, `title`, `message`, `cancelLabel`; emits `confirm` only after explicit acceptance |
| `LelloConfirmDialog` | Boolean `v-model`, required `title`, optional `message`, `confirmLabel`, `cancelLabel`, `danger`; emits `confirm` only for explicit acceptance |
| `LelloCard` | Optional `title`; bounded 8 px panel for genuinely contained content |
| `LelloSection` | Required `title`, optional `description`; open content section with a 2 px rule and a labelled region |
| `LelloAlert` | `tone`: info/success/warning/error; optional `title`; content slot |
| `LelloDialog` | Boolean `v-model`, required `title`; content and `actions` slots, actions exposes `close()` |
| `LelloConnectionStatus` | `state`: connected/connecting/disconnected; optional `labels` overrides and accessible `label` prefix |
| `LelloThemeSelector` | `v-model`: light/dark/system; optional `labels` overrides, accessible `label` prefix and `optionsLabel` |

Loading buttons are disabled and expose `aria-busy`; provide a meaningful visible
label such as “Saving”. Dialogs use native `showModal`, focus containment, Escape,
and focus return; they stay under the theme root, so top-layer rendering retains
inherited colors. No portal to an unthemed document body is required.

Use `LelloField` to wrap other native controls without duplicating label/error
relationships. Bind the slot's `id`, `aria-describedby`, `aria-invalid`, and
`required` to the actual control. Validation rules and server errors remain owned
by the consuming service. `LelloInput` is for string-valued inputs, not checkbox,
radio, file, or numeric coercion models.

Use `LelloTextarea` rather than rebuilding field/hint/error relationships around a
textarea. For a permission set, bind the same string array to several checkboxes
with distinct string values; keep business rules and grouping fieldsets in the app.

`LelloButtonLink` remains an anchor, not a button with click-driven navigation:
modified clicks, browser link menus, target and rel work normally. Its default
neutral appearance distinguishes navigation from the primary action. A router
adapter may intercept unmodified clicks while preserving its actual href.

`LelloConfirmDialog` builds on `LelloDialog`: Escape, Close, and Cancel only set
the model to false. Only the confirm button emits `confirm`. The consuming app
owns mutations, pending promises and cancellation on logout/navigation. The safe
close control receives initial focus; cancellation returns focus to the trigger.
Use danger styling for destructive confirmation, not ordinary navigation.

`LelloBadge` provides appearance only: the app maps domain states to tones. Keep
meaningful text in the slot; never rely on color alone. It is not a live region.

## Header controls

```vue
<template #header-actions>
  <div class="lv-header-controls">
    <LelloConnectionStatus :state="connectionState" />
    <LelloThemeSelector v-model="appearance" />
  </div>
</template>
```

Both components are imported from `@lelloman/lellodesign-vue`. Exported types are
`LelloConnectionState` and `LelloAppearance`. The dot exposes only a small floating
Connected / Connecting… / Disconnected label, not diagnostics. Use `label` to
identify the connection for assistive technology (default `Connection status`).
`labels` accepts a partial object keyed by the respective state/preference names
for translations. The theme trigger defaults to `Change theme`, and its choice
group to `Appearance`; both are overridable without changing selection behavior.

The components own no network, browser-online, storage, OS preference, or routing
logic. The host supplies connection state and maps appearance to the chosen
product palette. For System, listen to `matchMedia('(prefers-color-scheme: dark)')`
in the host and update `LelloTheme` without remounting content. Persist only the
appearance preference if desired. The playground demonstrates this separation.

See [header guidelines](../../docs/header-controls.md) for placement, keyboard,
focus, touch, labels and state semantics. The panel is a labeled group of buttons,
not a generic menu export. Instance IDs are generated with Vue `useId`.

## Content layout

The scaffold main region is fluid. Operational lists, tables and dashboards should
use that width, without a global `--ld-content-width` wrapper. `lv-workspace` is
a fluid content utility; `lv-utility` limits focused task regions to 640 px; `lv-prose` constrains reading blocks to 72ch and
`lv-editorial` centers editorial content at 1120 px. The existing content-width
token remains an editorial compatibility alias. Use `lv-scroll` for wide tables
and retain native table semantics. Field widths remain locally constrained.
See [product layouts](../../docs/product-layouts.md) and the
[Operations reference](../../screens/operations.md).

## Scaffold integration

```vue
<LelloScaffold
  product-name="My service"
  :items="items"
  :active="currentSection"
  mobile-navigation="bottom"
  :show-mobile-account="currentSection === 'settings'"
  @navigate="onNavigate"
>
  <template #logo><img src="/brand.svg" alt="" /></template>
  <template #nav-icon="{ item }"><MyIcon :name="item.id" /></template>
  <template #account="{ compact }">
    <LelloAccount :name="user.name" :src="user.picture" :compact="compact"
      @activate="accountOpen = true" />
  </template>
  <RouterView />
</LelloScaffold>
```

Navigation items are `{id, label, href}` with real destinations. Links retain
normal browser behavior unless the host calls `event.preventDefault()` in
`navigate`. For client-side routing, intercept only unmodified primary clicks
and pass the destination to your router. The host owns active state, route
changes, document titles, focus after navigation, and scroll restoration.

Slots: `logo`, `nav-icon({item})`, `account({compact})`, `header-actions`, and the
main content slot. Supply real product artwork; the fallback square and initial
navigation marks are placeholders. Do not put an account control in header-actions.

Desktop uses the 208 px sidebar / 80 px rail, chevron in the sidebar, and animated
collapse. Below 760 px it uses a native drawer, or bottom navigation when selected.
Choose a small set of destinations for bottom navigation. In bottom mode, bind
`showMobileAccount` to Settings visibility; otherwise the account is deliberately
hidden on mobile. The account slot is mounted once and teleported between internal
docks on resize. Its subtree stays alive. The drawer closes on desktop resize.
The account slot becomes available after mount when docks exist.

The host decides what `activate` opens and supplies actual identity/auth actions.
The demo's account dialog is not an auth integration. Both scaffold and dialogs
must be descendants of `LelloTheme`. The scaffold fills its available viewport;
use it once as the app shell, not as a nested panel.

## Verification and development

```sh
npm run build
npm run build:demo
npx playwright install chromium
npm test
npm pack --dry-run
```

To use a system Chromium instead of downloading a browser:

```sh
LELLO_CHROMIUM=/path/to/chromium npm test
```

Tests exercise the built exports: form/theme persistence, error relationships,
dialog Escape/focus return, scoped HTML styling and opt-out, mobile/desktop
account movement, bottom navigation, and reduced motion. Test your service's own
routing, keyboard flows, real content, and third-party components as well.

`npm run tokens` regenerates ignored build inputs from the repository's color and
layout tokens and selected account geometry. Do not edit generated copies.
Library builds externalize Vue, following [Vite library-mode guidance](https://vite.dev/guide/build.html#library-mode).

This first package does not yet include dedicated tabs, menus, comboboxes,
pagination, toasts, date pickers, or a data grid. Base styling and composition
support custom controls, but do not supply their accessibility behavior.

## Sign out

Place `LelloAccount` and `LelloSignOutButton` in a `lv-account-row` in the scaffold
account slot. The sign-out icon is directly visible beside the identity; never hide
it inside the account dialog. The row stacks in the rail and moves into the mobile
drawer with the account slot. The button defaults to icon-only with an accessible
name and hover title; `:icon-only="false"` adds a visible label. It renders the shared icon
and opens a confirmation dialog; Escape, Close and Cancel never emit `confirm`.
Bind `loading` to the pending logout request and call the host's logout handler
only on `confirm`. The component makes no authentication requests itself.
Override the message when the host discards unsaved local work.
See [account behavior](../../docs/family-comparison.md#account-identity-and-sign-out).

## Segmented control

`LelloSegmentedControl` selects one value from a short set of related choices,
such as a chart time range. Use `LelloSelect` for long option lists. This control
does not supply tab panels or navigation.

```vue
<LelloSegmentedControl
  v-model="range"
  label="CPU history range"
  :options="[
    { value: 'day', label: '24h', accessibleLabel: 'Past 24 hours' },
    { value: 'hour', label: '1h', accessibleLabel: 'Past hour' }
  ]"
/>
```

The required `modelValue` is a string, `options` is an array of exported
`LelloSegmentedOption` values, and `label` names the radio group for assistive
technology. Option values must be unique. Start with an enabled option selected;
the host owns fallback selection if options change. Each option has `value`,
`label`, optional `accessibleLabel`, and optional `disabled`. The group also
accepts `disabled` and an optional native radio `name` (generated by default).
When mounting separate Vue applications in one document, supply distinct names.
Selection emits `update:modelValue`; no persistence is built in.

Native radio inputs provide Tab, arrow-key and Space interaction, including
skipping disabled choices. Each target is 48px tall around a 40px visible control. The component uses
Material 3 rounded outer ends, semantic selection/focus/disabled colors, and supports
light, dark and forced-color appearances. Its playground includes enabled and
disabled examples.

### Segmented control appearance

The segmented control follows the Material Design 3 single-select pattern, using
LelloDesign semantic colors, connected outlines and a selected checkmark. Its
40 px visible height retains a 48 px pointer target. Native radio behavior supports
arrow keys; focus, disabled states and reduced motion are preserved.

Run `npm run gallery` and open
`http://127.0.0.1:5180/gallery/segmented-control.html` for the live source preview.

## Open-workspace design update (unreleased)

The scaffold now follows the accepted `07 B` reference: a 208 px sidebar (80 px
rail), neutral header divider, 32 px desktop / 16 px mobile gutters, and a selected
navigation item joined to the workspace with a 3 px edge. Bottom navigation places
the edge at the top. Controls use 4 px corners; cards and dialogs use 8 px.
Header titles are 24 px desktop / 20 px mobile; section titles are 20 px.
Inter is bundled locally with its license. `--ld-font-family` remains overridable.
Ship the complete `dist` folder, including `fonts/`, when copying assets manually.

Use open sections for settings and groups of controls:

```vue
<LelloScaffold product-name="My app" title="Settings" :items="items" active="settings">
  <div class="lv-workspace lv-utility">
    <LelloSection title="Profile" description="Choose how you appear to other members.">
      <LelloInput v-model="name" label="Display name" />
      <LelloButton @click="save">Save changes</LelloButton>
    </LelloSection>
  </div>
</LelloScaffold>
```

Import `LelloSection` from the package. `lv-workspace` supplies the shared vertical
rhythm; `lv-utility` optionally limits form width. The scaffold already supplies
page gutters. Do not add a second route title or nest ordinary sections in cards.
`LelloCard` remains available for actual enclosed surfaces; existing uses are not
automatically changed into sections. Scoped native tables are open, with a strong
header rule and quiet row separators.

`LelloAccount` is already one button: avatar, labels and padding activate the same
callback, with full-row hover/pressed/focus feedback. The host still owns the
account dialog/menu and can forward `aria-haspopup`/`aria-expanded` as appropriate.
The separate sign-out control retains its own confirmation behavior. Hover/press
color changes use 120 ms and become immediate under reduced motion; focus is
immediate. Sidebar resizing retains its established reduced-motion support.

No package version is published by this source update. See [release notes](RELEASES.md).
